//
//  testSDKpodJack.h
//  testSDKpodJack
//
//  Created by Jacek Kurbiel on 11/02/2020.
//  Copyright © 2020 Jacek Kurbiel. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for testSDKpodJack.
FOUNDATION_EXPORT double testSDKpodJackVersionNumber;

//! Project version string for testSDKpodJack.
FOUNDATION_EXPORT const unsigned char testSDKpodJackVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <testSDKpodJack/PublicHeader.h>


